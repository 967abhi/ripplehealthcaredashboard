var express=require('express');
var app=express();
const mysql=require('mysql');
const axios=require('axios');
const db=mysql.createConnection({
    host:"rippledatabase.cjiy17cnskqb.ap-south-1.rds.amazonaws.com",
    port:"3306",
    user:"admin",
    password:"Ripple123",
    database:"RippleHealthcare",
});
db.connect(err=>{
    if(err){
        console.log(err.message);
        return;
    }
    console.log('database connected');
});
app.use(express.static('public'));
app.set('view engine','ejs');

// ===================================
// 
// ========================================
app.listen(8080,()=>{
    console.log("port started ")
});
app.get('/login',function(req,res){
    res.render('pages/login');
})

// app.get('/login',function(req,res){
//     res.render('pages/login')
// })


app.use(express.urlencoded({ extended: true }));


// the login page of the post 
app.post('/login', (req, res) => {
    // Handle login logic here
    const { email, password } = req.body;

    // Check if the user exists in the database
    const selectQuery = 'SELECT  email, password FROM login_page WHERE email = ?';
    db.query(selectQuery, [email], (err, results) => {
        if (err) {
            console.error('Error querying the database:', err);
            res.send('Error during login.');
        } else if (results.length === 0) {
            res.send('User not found. Please sign up.');
        } else {
            const user = results[0];
            // Check if the provided password matches the stored password
            if (password === user.password) {
                // Passwords match; consider using a secure session management solution
                // and redirect the user to a protected route
                res.redirect('/');
            } else {
                res.send('Incorrect password. Please try again.');
            }
        }
    });
});










// =====


app.get('/',(req,res)=>{
    res.render('pages/home');
})
// ==============This is the sign up page where we are going to connect with the Database 

app.get('/SignupPage',(req,res)=>{
    res.render('pages/SignupPage');
})
app.post('/SignupPage',(req,res)=>{
    const {email,password,confirmPassword}=req.body;
    if(password=== confirmPassword){
        const insertQuery='INSERT INTO login_page (email, password) VALUES (?, ?)';
        db.query(insertQuery,[email,password],(err,result)=>{
            if(err){
                console.error('Error inserting user',err);
                res.send('Error signing up.');

            }
            else{
                res.redirect('/login');
            }
        });
    }
    else{
        res.send('password do not match ');
    }

});

app.get('/Message',(req,res)=>{
    res.render('pages/Message');
})

app.get('/MyStore',(req,res)=>{
    res.render('pages/MyStore');
})
app.get('/Analytics',async(req,res)=>{
    try {
        // Fetch employee data from the API
        const response = await axios.get('http://3.111.234.224/items/');
        const employees = response.data; // Assuming the API response is an array of employee objects

        // Render the "apifet" page template with the fetched employee data
        res.render('pages/Analytics', { employees });
    } catch (error) {
        console.error('Error fetching employee data:', error);
        res.status(500).send('An error occurred while fetching employee data.');
    }

})

app.get('/Team',(req,res)=>{
    res.render('pages/Team');

})
// app.get('/apifet',(req,res)=>{
//     res.render('pages/apifet');
// })
app.get('/apifet', async (req, res) => {
    try {
        // Fetch employee data from the API
        const response = await axios.get('http://3.111.234.224/items/');
        const employees = response.data; // Assuming the API response is an array of employee objects

        // Render the "apifet" page template with the fetched employee data
        res.render('pages/apifet', { employees });
    } catch (error) {
        console.error('Error fetching employee data:', error);
        res.status(500).send('An error occurred while fetching employee data.');
    }
});



