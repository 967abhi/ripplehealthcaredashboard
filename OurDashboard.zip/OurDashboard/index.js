var express=require('express');
var app=express();

app.use(express.static('public'));
app.set('view engine','ejs');


app.listen(8080,()=>{
    console.log("port started ")
});
app.get('/',function(req,res){
    res.render('pages/home');
})
app.get('/Message',(req,res)=>{
    res.render('pages/Message');
})

app.get('/MyStore',(req,res)=>{
    res.render('pages/MyStore');
})
app.get('/Analytics',(req,res)=>{
    res.render('pages/Analytics');

})

app.get('/Team',(req,res)=>{
    res.render('pages/Team');

})
