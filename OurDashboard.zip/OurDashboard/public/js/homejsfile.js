const AnalyticLine=document.getElementById('myAnalyticsChart');
const Dailyuser=document.getElementById('myBarChart');
const xValues = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31];

new Chart( AnalyticLine, {
type: "line",
data: {
  labels: xValues,
  datasets: [{
    data: [5,2,4,3,9,4,10,2,1,0,18,16,25,77,5,2,3,9,0,4,5,3,2,1,25,26,27,42,29,65,0],
    borderColor: "red",
    fill: false,
    label:"October"
  },{
    data: [16,17,18,19,20,25,30,40,71,70,0,2,3,4,0,5,0,3,9,0,0,4,0,8,1,5,6,8,11,29,0],
    borderColor: "green",
    fill: false,
    label:"September "
  },{
    data: [30,70,2,50,60,40,20,100,20,10,14,15,18,1,9,2,3,8,5,64,100,80,50,20,34,0,70,6,5,4,100],
    borderColor: "blue",
    fill: false,
    label:"August"
  }]
},
options: {
  scales: {
    y: {
      beginAtZero: true, // Start the Y-axis from zero
      ticks: {
        stepSize: 10, // Adjust the step size as needed
        max: 300, // Set the maximum value to 100
      }
    },
  },
  legend: {display: false}
}
});



new Chart(Dailyuser, {
    type: 'bar',
    data: {
      labels: ['July', 'August', 'September', 'October'],
      datasets: [{
        label: 'Data Of My Monthly User ',
        data: [21, 29, 43, 25],
        backgroundColor:[
                  'rgb(255,99,132)',
                  'rgb(69,194,194)',
                  'rgb(255,204,81)',
                  'rgb(54,162,235)',
                 
        ],
        borderColor:[
            'rgba(255,99,132,1)',
            'rgba(54,162,235,1)',
            'rgba(255,206,86,1)',
            'rgba(75,192,192,1)',
           
        ],
        borderWidth: 1
        
      }]
    },
    options: {
      responsive:true,
    }
  });